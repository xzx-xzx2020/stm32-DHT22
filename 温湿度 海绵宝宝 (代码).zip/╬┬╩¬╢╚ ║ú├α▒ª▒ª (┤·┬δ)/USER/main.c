#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "oled.h"
#include "dht22.h" 


int main(void)
{ 
	u8 t=0;
	u16 temperature,temperature1,temperature2,humidity1,humidity2;  	    
	u16 humidity;    
	delay_init();	    	 //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	//uart_init(115200);	 //���ڳ�ʼ��Ϊ115200
 	//LED_Init();			     //LED�˿ڳ�ʼ��
	//KEY_Init();          //������ʼ��
	OLED_Init();
	OLED_Clear(); 
	while(DHT22_Init())	//DHT22��ʼ��
	{
		OLED_ShowString(20,0,"DHT22 err",16);
		delay_ms(200);
		OLED_Clear(); 
 		delay_ms(200);
		//LED_BLUE=!LED_BLUE;
	}
	OLED_ShowString(20,1,"Design By:",16);
	OLED_ShowCHinese(40,3,3);// show zhi
	OLED_ShowCHinese(56,3,4);// show xing
	OLED_ShowString(20,5,"2020-6-15",16);
	delay_ms(1500);
	delay_ms(1500);
	OLED_Clear(); 
	OLED_ShowString(15,2,"Temp:  . C",16);
	OLED_ShowCHinese(15,2,0);
	OLED_ShowCHinese(31,2,2);
	OLED_ShowString(15,5,"Humi:  . %",16);
	OLED_ShowCHinese(15,5,1);
	OLED_ShowCHinese(31,5,2);
	
	while(1) 
	{		
    if(t == 10 || t == 0)			//ÿ100ms��ȡһ��
		{	
			t = 0;
			if(DHT22_Read_Data(&temperature,&humidity) == 1)//��ȡ��ʪ��ֵ
			{
				// read erro
				OLED_ShowString(20,0,"DHT22 err",8);
				delay_ms(200);
			}
			else
			{
				// read suc
				OLED_ShowString(20,0,"DHT22 suc",8);
				temperature1 = temperature/10;
				temperature2 = temperature%10;
				humidity1 = humidity/10;
				humidity2 = humidity%10;
				OLED_ShowNum(55,2,temperature1,2,16);
				OLED_ShowNum(78,2,temperature2,1,16);
				OLED_ShowNum(55,5,humidity1,2,16);
				OLED_ShowNum(78,5,humidity2,1,16);
			}
		}				   
	 	delay_ms(150);
		t++;
	}	
}

